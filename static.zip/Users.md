Admin:
Username: admin
Password: admin123
Email: admin@farm2home.com
Role: Admin

Farmers:
Username: farmer1
Password: farmerpass
Email: farmer1@farm2home.com
Name: John Smith
Farm: Green Valley Farm

Username: farmer2
Password: farmerpass
Email: farmer2@farm2home.com
Name: Maria Garcia
Farm: Sunshine Organic Farm

Customers:
Username: customer1
Password: customerpass
Email: customer1@farm2home.com
Name: Alice Johnson
